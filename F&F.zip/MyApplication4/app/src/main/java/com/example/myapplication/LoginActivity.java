package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.google.gson.GsonBuilder;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private EditText userIdEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private TextView statusTextView;

    // TODO: 서버 IP 주소 설정
    private static final String BASE_URL = "http://192.168.13.0:8080/"; // 실제 기기용 (PC의 Wi-Fi IP)
    // private static final String BASE_URL = "http://10.0.2.2:8080/"; // 에뮬레이터용

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userIdEditText = findViewById(R.id.userId_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginButton = findViewById(R.id.login_button);
        statusTextView = findViewById(R.id.status_text_view);

        // Retrofit 클라이언트 설정
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(logging)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(new GsonBuilder().setLenient().create()))
                .client(client)
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userId = userIdEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (userId.isEmpty() || password.isEmpty()) {
                    statusTextView.setText("아이디와 비밀번호를 모두 입력해주세요.");
                    return;
                }

                UserLoginRequest request = new UserLoginRequest(userId, password);

                apiService.login(request).enqueue(new Callback<UserLoginResponse>() {
                    @Override
                    public void onResponse(Call<UserLoginResponse> call, Response<UserLoginResponse> response) {
                        if (response.isSuccessful()) {
                            // 로그인 성공
                            String message = "로그인 성공! 환영합니다.";
                            Log.d(TAG, message + " 응답: " + response.body().toString());
                            statusTextView.setText(message);
                            // TODO: 로그인 성공 후 다음 화면으로 이동
                        } else {
                            // 로그인 실패
                            String errorMessage = "로그인 실패: " + response.code();
                            Log.e(TAG, errorMessage);
                            statusTextView.setText("로그인에 실패했습니다. 아이디와 비밀번호를 확인해주세요.");
                        }
                    }

                    @Override
                    public void onFailure(Call<UserLoginResponse> call, Throwable t) {
                        // 네트워크 오류
                        String errorMessage = "네트워크 오류: " + t.getMessage();
                        Log.e(TAG, errorMessage);
                        statusTextView.setText("서버와 통신할 수 없습니다.");
                    }
                });
            }
        });
    }
}