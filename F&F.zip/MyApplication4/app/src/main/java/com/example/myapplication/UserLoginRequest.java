package com.example.myapplication;

import com.google.gson.annotations.SerializedName;

public class UserLoginRequest {

    @SerializedName("userId")
    private String userId;

    @SerializedName("password")
    private String password;

    public UserLoginRequest(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }
}