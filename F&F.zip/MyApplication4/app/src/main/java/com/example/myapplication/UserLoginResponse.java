package com.example.myapplication;

import com.google.gson.annotations.SerializedName;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class UserLoginResponse {
    @SerializedName("message")
    private String message;
}